# Football Predictor — MVP 0.2

Web app responsive basata su Streamlit per calendario e stime pre-partita.

## Avvio
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```
Copia `.env.example` in `.env` e inserisci la chiave API-Football:
```env
APISPORTS_KEY=la_tua_chiave
```
Avvia:
```bash
streamlit run app.py
```
Per accedere da smartphone sulla stessa rete Wi-Fi:
```bash
streamlit run app.py --server.address 0.0.0.0
```

## Motore statistico 0.2
- Stagione corrente: medie gol fatti/subiti con split casa/trasferta tramite `teams/statistics`.
- Forma recente: ultime 10 partite concluse, gol fatti/subiti con pesi crescenti per le gare più recenti.
- Combinazione: 65% dato stagionale + 35% forma recente, quando entrambe le fonti sono disponibili.
- xG stimati con forza offensiva della squadra e vulnerabilità difensiva avversaria rispetto a baseline casa/trasferta.
- Distribuzione Poisson per risultato esatto, 1X2, Over/Under 2.5 e Goal.
- Cache 30 minuti per calendario e 24 ore per profili squadra.
- Archivio SQLite locale delle previsioni salvate.

## Limiti e trasparenza
1. La copertura dei dati dipende dalla competizione, dalla stagione e dal piano API.
2. Se l'API non restituisce statistiche, l'app segnala il fallback neutro: non spaccia quel dato per una previsione personalizzata.
3. La versione attuale non include ancora xG reali da provider, infortuni, quote o correzione Dixon-Coles.
4. Il modello deve essere validato con backtesting cronologico prima di essere considerato affidabile.
5. La chiave API è conservata in `.env` sul server e non va inserita nel codice pubblicato.

## Fonte API
API-Football v3: `/fixtures`, `/teams/statistics`. Controllare piano, copertura e quote aggiornate sul portale ufficiale.
