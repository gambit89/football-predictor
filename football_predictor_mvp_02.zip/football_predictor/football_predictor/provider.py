import requests

class APIFootballProvider:
    """API-Football v3 adapter. Keep the API key server-side."""
    def __init__(self, api_key: str, base_url: str):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({"x-apisports-key": api_key})

    def _get(self, endpoint, params):
        response = self.session.get(f"{self.base_url}/{endpoint.lstrip('/')}",
                                    params=params, timeout=25)
        response.raise_for_status()
        payload = response.json()
        if payload.get("errors"):
            raise RuntimeError(str(payload["errors"]))
        return payload.get("response", [])

    def get_next_fixtures(self, count: int = 50):
        items = self._get("fixtures", {"next": min(max(int(count), 1), 99),
                                      "timezone": "UTC"})
        fixtures = []
        for item in items:
            fx, teams, league = item.get("fixture", {}), item.get("teams", {}), item.get("league", {})
            fixtures.append({
                "fixture_id": fx.get("id"), "date": fx.get("date"),
                "league": league.get("name", "Competizione"),
                "league_id": league.get("id"), "season": league.get("season"),
                "country": league.get("country", ""),
                "home": teams.get("home", {}).get("name", "Casa"),
                "away": teams.get("away", {}).get("name", "Trasferta"),
                "home_id": teams.get("home", {}).get("id"),
                "away_id": teams.get("away", {}).get("id"),
                "status": fx.get("status", {}).get("short", "NS"),
            })
        return fixtures

    def get_last_fixtures(self, team_id: int, count: int = 10, before_date=None):
        params = {"team": int(team_id), "last": min(max(int(count), 1), 20),
                  "timezone": "UTC"}
        if before_date:
            params["to"] = str(before_date)[:10]
        return self._get("fixtures", params)

    def get_team_season_stats(self, team_id: int, league_id: int, season: int, before_date=None):
        params = {"team": int(team_id), "league": int(league_id), "season": int(season)}
        if before_date:
            params["date"] = str(before_date)[:10]
        data = self._get("teams/statistics", params)
        return data[0] if data else None
