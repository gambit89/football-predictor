import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path(__file__).resolve().parent.parent / "football_predictor.db"

def save_prediction(fixture, prediction):
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""CREATE TABLE IF NOT EXISTS predictions (
            fixture_id INTEGER, generated_at TEXT, home TEXT, away TEXT,
            lambda_home REAL, lambda_away REAL, predicted_score TEXT,
            p_home REAL, p_draw REAL, p_away REAL, actual_home INTEGER,
            actual_away INTEGER, PRIMARY KEY(fixture_id, generated_at))""")
        con.execute("""INSERT INTO predictions
            (fixture_id, generated_at, home, away, lambda_home, lambda_away,
             predicted_score, p_home, p_draw, p_away)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (fixture.get("fixture_id"), datetime.now(timezone.utc).isoformat(),
             fixture.get("home"), fixture.get("away"), prediction["lambda_home"],
             prediction["lambda_away"], prediction["most_likely_score"],
             prediction["home_win"], prediction["draw"], prediction["away_win"]))
