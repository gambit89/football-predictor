import os
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("APISPORTS_KEY", "").strip()
API_BASE_URL = os.getenv("APISPORTS_BASE_URL", "https://v3.football.api-sports.io").rstrip("/")
